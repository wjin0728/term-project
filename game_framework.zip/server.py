player_one = None
player_two = None
p1_win = None
p2_win = None

who_win = 0
