import pico2d
import game_framework

import menu_mode as start_mode

pico2d.open_canvas(game_framework.screen_width, game_framework.screen_height)
game_framework.run(start_mode)
pico2d.close_canvas()


# 2022180031 이우진
